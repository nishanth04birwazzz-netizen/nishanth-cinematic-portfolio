# Nishanth Birwazz — Cinematic Portfolio

A responsive cinematic portfolio with an original streaming-platform-inspired visual identity: dark backgrounds, red accents, episode-like sections, and project cards called “Originals.” It is not affiliated with any streaming service and uses no streaming-service logos.

## Run locally
- Open `index.html` in a modern browser, or
- Open this folder in VS Code and use the Live Server extension.

No build step or package installation is required. HTML, CSS, and JavaScript are separate for easy editing.

## Customize
- Edit content, project descriptions, and links in `index.html`.
- Change colors and layout in `styles.css`.
- Edit menu behavior and reveal animations in `script.js`.

## Links currently used
- GitHub: https://github.com/nishanth04birwazzz-netizen
- StudyVault: https://github.com/nishanth04birwazzz-netizen/study-vault
- LinkedIn: https://www.linkedin.com/in/nishanth-poojary-325573406
- Email: nishanth04birwazzz@gmail.com

Project cards are labelled as in development where appropriate. Update them as project status changes.

## Publish
Deploy these static files using GitHub Pages, Netlify, or Firebase Hosting.
